# basic_math_operations

Description. 
The package package_name is used to:
	- Add
	- Subtract
	extra:
		- Multipliply
		- Divide
	

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install basic_math_operations
```
## Author
Hector

## License
